# Gambling Addiction Satisfier

A casino gaming website with multiple games including Roulette, Horse Racing, Blackjack, and Slot Machine. Features include:

- User profile setup with avatars
- Real-time chat system
- Money transfer between users
- Win notifications
- Multiple casino games

## Games Available:
- 🎰 Roulette (Currently locked)
- 🐎 Horse Racing
- 🃏 Blackjack  
- 🎰 Slot Machine

## Features:
- 💬 Live chat with other players
- 💰 Send money to other users
- 🎉 Win notifications in chat
- 🎮 Interactive gaming experience

Built with HTML, CSS, and JavaScript.
